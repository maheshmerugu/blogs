<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PlanSubscription extends Model
{
    use HasFactory;

    protected $fillable = ['plan_name','months','access_to_video','access_to_notes','access_to_question_bank','amount','discount','watch_hours','payble_amount'
      
    ];



    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        
        'months' => 'integer',
        'watch_hours' => 'integer',
        'access_to_video' => 'integer',
        'access_to_notes' => 'integer',
        'access_to_question_bank' => 'integer',
        'amount' => 'integer',
        'discount' => 'integer',
        'payble_amount' => 'double',
        'plan_type' => 'integer',
    ]; 
}
