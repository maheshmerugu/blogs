<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VideoPlayStatus extends Model
{
    use HasFactory;

    protected $fillable = ['video_id','subcription_id','user_id','watch_time','status'];

     /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'subcription_id' => 'datetime',
        'video_id' => 'integer',
        'user_id' => 'integer',
        'status' => 'integer',
    ];
    
}
